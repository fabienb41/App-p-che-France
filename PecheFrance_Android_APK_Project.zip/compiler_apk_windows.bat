@echo off
echo === Compilation de PecheFrance Reglementation au format APK ===
call npm install
call npx cap add android
call npx cap sync android
cd android
call gradlew.bat assembleDebug
echo.
echo === TERMINE ! Votre fichier APK se trouve ici : ===
echo android\app\build\outputs\apk\debug\app-debug.apk
pause
