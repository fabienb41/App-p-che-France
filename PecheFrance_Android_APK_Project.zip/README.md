# PêcheFrance Réglementation — Package Android & APK

Ce dossier contient le projet complet prêt à être compilé en fichier `.apk` installable sur votre téléphone Android.

## Méthode 1 : Compiler l'APK automatiquement en ligne (Sans rien installer sur votre PC)
1. Créez un dépôt gratuit sur **GitHub.com** et envoyez-y le contenu de ce dossier.
2. Allez dans l'onglet **Actions** de votre dépôt GitHub et lancez le workflow **Build Android APK**.
3. Au bout de 2 minutes, téléchargez directement le fichier **`PecheFrance-Reglementation-APK`** (`app-debug.apk`).
4. Transférez `app-debug.apk` sur votre téléphone Android et appuyez dessus pour l'installer.

## Méthode 2 : Compiler l'APK sur votre ordinateur (Windows / Mac / Linux)
Prérequis : Node.js (v18+) et Android Studio (SDK Android + Java 17).
1. Double-cliquez sur `compiler_apk_windows.bat` (ou exécutez `npm install && npx cap add android && npx cap sync android && cd android && ./gradlew assembleDebug`).
2. Récupérez le fichier APK généré dans :
   `android/app/build/outputs/apk/debug/app-debug.apk`
